import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';

import { TabsPage } from '../pages/tabs/tabs';
import { AbrirChamadoPageModule } from '../pages/abrir-chamado/abrir-chamado.module';
import { ListarAbertosPageModule } from '../pages/listar-abertos/listar-abertos.module';
import { ListarTodosPageModule } from '../pages/listar-todos/listar-todos.module';



import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { AbrirChamadoPage } from '../pages/abrir-chamado/abrir-chamado';
import { ListarAbertosPage } from '../pages/listar-abertos/listar-abertos';
import { ListarTodosPage } from '../pages/listar-todos/listar-todos';

@NgModule({
  declarations: [
    MyApp,
    TabsPage,
    AbrirChamadoPage,
    ListarAbertosPage,
    ListarTodosPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    TabsPage,
    AbrirChamadoPage,
    ListarAbertosPage,
    ListarTodosPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
