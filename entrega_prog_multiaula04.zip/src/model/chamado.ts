export interface Chamado
{
    id: number;
    categoria: string;
    descricao: string;
}