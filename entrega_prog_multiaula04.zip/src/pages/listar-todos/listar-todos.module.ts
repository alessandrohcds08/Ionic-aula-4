import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ListarTodosPage } from './listar-todos';

@NgModule({
  declarations: [
    ListarTodosPage,
  ],
  imports: [
    IonicPageModule.forChild(ListarTodosPage),
  ],
})
export class ListarTodosPageModule {}
