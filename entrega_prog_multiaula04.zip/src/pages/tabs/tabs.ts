import { Component } from '@angular/core';

import { AbrirChamadoPage } from '../abrir-chamado/abrir-chamado';
import { ListarAbertosPage } from '../listar-abertos/listar-abertos';
import { ListarTodosPage } from '../listar-todos/listar-todos';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = AbrirChamadoPage;
  tab2Root = ListarAbertosPage;
  tab3Root = ListarTodosPage;


  constructor() {

  }
}
